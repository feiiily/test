import { Link } from "react-router-dom";

function HomePage(){
    return (
        <div>
            <h1>welcome</h1>
            {/* <Link to={"/todo"}>Todo</Link>
            <Link to={"/hakernews"}>Haker News</Link> */}
            <Link to={"/login"}>login</Link>
            <Link to={"/index"}>index</Link>
            <Link to={"/editUserInformation"}>editUserInformation</Link>
        </div>
    );
}

export default HomePage;