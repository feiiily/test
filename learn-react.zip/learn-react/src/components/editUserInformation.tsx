import "./editUserInformation.css";
import axios from "axios";
import { useState } from "react";

function EditUserInformation(){
    const userInformation={
        nickname:"testname",
        email:"12306@qq.com",
        avatar:"这是图片",
        password:"123456",
        telephone:"123456789"
    };


    return (
        <div className="background_changeInformation">
            <h1 className="headline">修改用户信息</h1>
            <div className="changeInformationBorder">
            <ul>
                <li className="liStyle">头像：{userInformation.avatar}</li>
                <li>昵称：{userInformation.nickname}</li>
                <li>电话：{userInformation.telephone}</li>
                <li>电子邮件:{userInformation.email}</li>
                <li>密码：{userInformation.password}</li>
            </ul>
            <input type="button" className="clickButton" value="修改" />
            <input type="button" className="clickButton" value="注销" />
            <input type="button" className="clickButton" value="返回" />
            </div>
        </div>
    )
}

export default EditUserInformation;